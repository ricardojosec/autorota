
package br.com.autorota.autorotamanager.model;



import java.io.Serializable;
import javax.faces.bean.RequestScoped;
import javax.persistence.Column;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Entity;
/**
 *
 * @author ricardo.costa
 */
@Entity
@RequestScoped
@PrimaryKeyJoinColumn(name="idpessoa")
public class Usuario extends Pessoa implements Serializable {
    

    
    @Column(nullable=true, unique=true)
    private String senha;
    
     @Column(nullable=true)
    private String funcao;
     

    /**
     * @return the senha
     */
    public String getSenha() {
        return senha;
    }

    /**
     * @param senha the senha to set
     */
    public void setSenha(String senha) {
        this.senha = senha;
    }

    /**
     * @return the funcao
     */
    public String getFuncao() {
        return funcao;
    }

    /**
     * @param funcao the funcao to set
     */
    public void setFuncao(String funcao) {
        this.funcao = funcao;
    }
    
    
}
