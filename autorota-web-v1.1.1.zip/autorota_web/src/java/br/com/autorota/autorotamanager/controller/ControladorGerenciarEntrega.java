/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.autorota.autorotamanager.controller;


import br.com.autorota.autorotamanager.model.Entrega;
import br.com.autorota.autorotamanager.model.Pessoa;
import br.com.autorota.autorotamanager.model.Rotas;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.annotation.ManagedBean;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

/**
 *
 * @author ricardo.costa
 */
@ManagedBean
@SessionScoped
@Named(value = "ControladorGerenciarEntrega")

public class ControladorGerenciarEntrega implements Serializable {

    private List<Entrega> listaEntregas;
    private List<Pessoa> listaPessoas;
    private List<Rotas> listaRotas;
    /**
     * Creates a new instance of ControladorGerenciarEntrega
     */private Entrega entrega;
    
    private Pessoa pessoa;
    private Rotas rotas;
    private String display="";
    
    
    String nomePessoa;
    private String defaultColumnFilter;


    public ControladorGerenciarEntrega() {
        entrega=new Entrega();
        pessoa = new Pessoa ();
        rotas = new Rotas ();
        
    }

    public List<Entrega> obterListaEntrega() {
        Entrega e = new Entrega();
        listaEntregas = e.getList();
        System.out.println("Aqui");
        return e.getList();
    }
    
    
    
    public List<Pessoa> obterListaPessoa() {
        Pessoa p = new Pessoa();
        listaPessoas = p.getList();
        System.out.println("Aqui");
        return p.getList();
    }
    
    public List<Rotas> obterListaRotas() {
        Rotas r = new Rotas();
        listaRotas = r.getList();
        System.out.println("Aqui");
        return r.getList();
    }

    /**
     * @return the entrega
     */
    public Entrega getEntrega() {
        return entrega;
    }

    /**
     * @param entrega the entrega to set
     */
    public void setEntrega(Entrega entrega) {
        this.entrega = entrega;
    }

    /**
     * @return the listaEntregas
     */
    public List<Entrega> getListaEntregas() {
        return listaEntregas;
    }
    
    public Entrega search(long id){
        Entrega e = new Entrega();
        System.out.println("Aqui");
        return e.search(id);
              
    }
    
       public List<Pessoa> searchpessoas(String nome) {
       Pessoa p = new Pessoa();
       p.setNome(nome);
       listaPessoas = (List<Pessoa>) p.searchpessoa(nome);
       System.out.println("Aqui");
       return (List<Pessoa>) p.searchpessoa(nome);
    }
       
       
   
    private Pessoa selected;

    public Pessoa getSelected() {
        return selected;
    }

    public void setSelected(Pessoa selected) {
        this.selected = selected;
        ///entrega.setDestinatario(selected);
      
    }
    
    // Actions
    public List<Pessoa> completePessoa(){
        return pessoa.getList();
    }
    public String clear(){
        this.selected = null;
        return "";
    }
      

    /**
     * @param listaEntregas the listaEntregas to set
     */
    public void setListaEntregas(List<Entrega> listaEntregas) {
        this.listaEntregas = listaEntregas;
    }

    /**
     * @return the pessoa
     */
    public Pessoa getPessoa() {
        return pessoa;
    }

    /**
     * @param pessoa the entrega to set
     */
    public void setPessoa(Pessoa pessoa) {
        this.pessoa = pessoa;
    }

    /**
     * @return the listaPessoas
     */
    public List<Pessoa> getListaPessoas() {
        return listaPessoas;
    }
    

    /**
     * @param listaPessoas the listaEntregas to set
     */
    public void setListaPessoas(List<Pessoa> listaPessoas) {
        this.listaPessoas = listaPessoas;
        
    }
    
    
    
    public Rotas getRotas() {
        return rotas;
    }

    /**
     * @param rotas the rotas to set
     */
    public void setRotas(Rotas rotas) {
        this.rotas = rotas;
    }

    /**
     * @return the listaRotass
     */
    public List<Rotas> getListaRotass() {
        return listaRotas;
    }
    

    /**
     * @param listaRotas the listaEntregas to set
     */
    public void setListaRotas(List<Rotas> listaRotas) {
        this.listaRotas = listaRotas;
    }
    
    
    /** Metodos para Entrega
     * @return  */
    
    public String add (){
       this.setEntrega(entrega);
       SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yy");
       
       this.entrega.setDatahora(sdf.format(new Date()));
       this.entrega.inserir( );
       this.entrega = new Entrega();
       return "entregas"; 
      
    }
    
    public String alterar(Entrega e){
     this.entrega = e;
     
     return "editar_entrega";
      
    }
    
    public String alterar (){
       this.setEntrega(entrega);
       SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yy HH:mm:ss");
       
       this.entrega.setDatahora(sdf.format(new Date()));
       this.entrega.alterar( );
       this.entrega = new Entrega ();
       return "editar_entrega"; 
      
    }
    
    public String del (Entrega e){
       this.entrega.excluir();
       return "entregas"; 
      
    }
    
    /** Metodos para Pessoa
     * @return  */
   
   public String addPessoa (){
       this.setPessoa(pessoa);
       this.pessoa.inserir( );
       return "entregas"; 
      
    }
   
    public String alterarPessoa(Pessoa p){
     this.pessoa = p;
    
     return "entregas";
      
    }
    
    public String alteraPessoa (){
       this.setPessoa(pessoa);
       this.pessoa.alterar( );
       return "entregas"; 
      
    }
    
    public String delPessoa (){
       this.setPessoa(pessoa);
       this.pessoa.excluir( );
       return "entregas"; 
      
    }
    

    
    /** Metodos para Rotas
     * @return  */
   
   public String addRotas (){
       this.setRotas(rotas);
       this.rotas.inserir( );
       return "entregas"; 
      
    }
   
    public String alterarRotas(Rotas r){
     this.rotas = r;
    
     return "entregas";
      
    }
    
    public String alteraRotas (){
       this.setRotas(rotas);
       this.rotas.alterar( );
       return "entregas"; 
      
    }
    
    public String delRotas (){
       this.setRotas(rotas);
       this.rotas.excluir( );
       return "entregas"; 
      
    }
    
    public String getDefaultColumnFilter() {
  if ("aguardando".equals(defaultColumnFilter)) {
    return null;
  }
  return defaultColumnFilter;
}
    
    


}




