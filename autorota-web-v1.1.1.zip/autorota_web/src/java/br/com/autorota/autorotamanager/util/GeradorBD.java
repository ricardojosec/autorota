/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.autorota.autorotamanager.util;

import br.com.autorota.autorotamanager.controller.ControladorGerenciarEntrega;
import br.com.autorota.autorotamanager.controller.ControladorGerenciarPessoas;
import br.com.autorota.autorotamanager.model.Rotas;
import br.com.autorota.autorotamanager.model.Pessoa;
import br.com.autorota.autorotamanager.model.Fisica;
import br.com.autorota.autorotamanager.model.Juridica;
import br.com.autorota.autorotamanager.model.Endereco;
import java.util.List;

/**
 *
 * @author ricardo.costa
 */
public class GeradorBD {
    
    public static void main(String[] args) {
      
 
//  /* Criando a entrega */
            Rotas rota2  = new Rotas();
            rota2.setOrigem ("RJ");
            rota2.setDestino ("SP");
            rota2.setRastreio ("Em transito");
            rota2.setDatachegada (12);
            
            rota2.inserir();
//
//  
//        Endereco endereco1 = new Endereco();
//        endereco1.setCep("20766580");
//        endereco1.setLogradouro("rua terras cinzas");
//        endereco1.setCidade("Rio de janeiro");
//        endereco1.setUf("RJ");
//        endereco1.setEntrega(entrega1);
//        endereco1.inserir();

        //cliente1.setEntrega(entrega1);
        
       
        
      
        
         //Fisica fisica4 = new Fisica();

        //fisica4.setCpf("9087");
        //fisica4.setRg("9998");
        //fisica4.setNome("Ana");
        //fisica4.setEmail("Ana@gmail.com");
        //fisica4.setTelefone(99999);
        //fisica4.inserir();
        
        
        
        
        
       
    
    }
    
}

