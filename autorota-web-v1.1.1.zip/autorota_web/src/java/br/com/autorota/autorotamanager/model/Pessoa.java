
package br.com.autorota.autorotamanager.model;

import java.io.Serializable;
import javax.faces.component.UIInput;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.OneToOne;



@Entity
@Inheritance(strategy = InheritanceType.JOINED)
public class Pessoa extends Modelo<Pessoa> implements Serializable{
    
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
     private Long idpessoa;
    @Column(nullable=true)
     private String nome;
    @Column(nullable=true)
     private long telefone;
    @Column(nullable=true)
     private String email;
    @OneToOne(cascade = CascadeType.ALL)
    private Endereco endereco;
    

    public Pessoa (){
        
        endereco=new Endereco();
    
    }
    
    
    public long getIdpessoa() {
        return idpessoa;
    }

    
    public void setIdpessoa(long idpessoa) {    
        this.idpessoa = idpessoa;
    }

    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the telefone
     */
    public long getTelefone() {
        return telefone;
    }

    /**
     * @param telefone the telefone to set
     */
    public void setTelefone(long telefone) {
        this.telefone = telefone;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the endereco
     */
    public Endereco getEndereco() {
        return endereco;
    }

    /**
     * @param endereco the endereco to set
     */
    public void setEndereco(Endereco endereco) {
        this.endereco = endereco;
    }
    


}
    

