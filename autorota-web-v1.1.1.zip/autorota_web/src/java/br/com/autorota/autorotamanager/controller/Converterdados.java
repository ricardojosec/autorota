/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.autorota.autorotamanager.controller;

import br.com.autorota.autorotamanager.dao.GenericDAO;
import br.com.autorota.autorotamanager.model.Modelo;
import br.com.autorota.autorotamanager.model.Pessoa;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

/**
 *
 * @author ricardo.costa
 */

@FacesConverter(value = "Converter")
public class Converterdados implements Converter {
    
    Pessoa p = new Pessoa();
    @Override
    public Object getAsObject(FacesContext context, UIComponent component, String value) {
       return p.searchpessoa(value);
        
    }
    @Override
    public String getAsString(FacesContext context, UIComponent component, Object value) {
        Pessoa c = (Pessoa) value;
        return c.getNome();
    }

    
}
    

