/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.autorota.autorotamanager.controller;


/*
 * A Bean Used for Demo purposes
 */

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;

import javax.faces.bean.ManagedBean;

import javax.faces.bean.SessionScoped;
import javax.faces.event.ActionEvent;
import javax.inject.Named;


/**
 * @author Stephan Rauh, http://www.beyondjava.net
 */
@ManagedBean
@SessionScoped
@Named(value = "ControladorGerenciarBusca")
public class ControladorGerenciarBusca implements Serializable {
    
    private List<String> data =null;
    private List<String> result = null;
    private String display="";
    
    @PostConstruct
    public void init(){
        data=new ArrayList<String>();
        result=new ArrayList<String>();
        
        data.add("Antigua and Barbuda");
        data.add("Argentina");
        data.add("Aruba");
        data.add("Afghanistan");
        data.add("Azerbaijan");
    }
    
    public void search(){
        result.clear();
        for(String country:data){
            if(country.toLowerCase().startsWith(display.toLowerCase())){
                result.add(country);
            }
        }
        
        if(result.isEmpty()){
            result.add("Not Found");
        }
    }

    public List<String> getResult() {
        return result;
    }

    public void setResult(List<String> result) {
        this.result = result;
    }

    public String getDisplay() {
        return display;
    }

    public void setDisplay(String display) {
        this.display = display;
    }
    
    
    
    
}
    
    

