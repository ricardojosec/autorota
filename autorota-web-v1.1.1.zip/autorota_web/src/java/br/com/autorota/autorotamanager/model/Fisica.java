/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.autorota.autorotamanager.model;

import java.io.Serializable;
import javax.persistence.Column;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
/**
 *
 * @author alunoti
 */
@Entity
@PrimaryKeyJoinColumn(name="idpessoa")
public class Fisica extends Pessoa implements Serializable{
    
    @Column(nullable=true, unique=true)
    private String cpf;
    
    @Column(nullable=true, unique=true)
    private String rg;
    

    /**
     * @return the cpf
     */
    public String getCpf() {
        return cpf;
    }

    /**
     * @param cpf the cpf to set
     */
    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    /**
     * @return the rg
     */
    public String getRg() {
        return rg;
    }

    /**
     * @param rg the rg to set
     */
    public void setRg(String rg) {
        this.rg = rg;
    }
   
    
}
