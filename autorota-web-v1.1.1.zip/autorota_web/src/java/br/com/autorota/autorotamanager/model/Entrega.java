
package br.com.autorota.autorotamanager.model;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

/**
 *
 * @author alunoti
 */
@Entity
@Inheritance(strategy = InheritanceType.JOINED)
public class Entrega extends Modelo<Entrega> implements Serializable {


  //  private List<Endereco> enderecos;
  
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long idEntrega;
    private long altura;
    private long largura;
    private long nfe;
    private long peso;
    private String produto;
    private long profundidade;
    private String status;
    private String datahora;
    private String remetente;
    private String destinatario;
    private String uforigem;
    private String ufdestino;
    private String observacao;
    private String filiais;
    
    
    

    /**
     * @return the enderecos
     */
//    public List<Endereco> getEnderecos() {
//        return enderecos;
//    }
//
//    /**
//     * @param enderecos the enderecos to set
//     */
//    public void setEnderecos(List<Endereco> enderecos) {
//        this.enderecos = enderecos;
//    }

    /**
     * @return the idEntrega
     */
    public long getIdEntrega() {
        return idEntrega;
    }

    /**
     * @param idEntrega the idEntrega to set
     */
    public void setIdEntrega(long idEntrega) {
        this.idEntrega = idEntrega;
    }

    /**
     * @return the altura
     */
    public long getAltura() {
        return altura;
    }

    /**
     * @param altura the altura to set
     */
    public void setAltura(long altura) {
        this.altura = altura;
    }

    /**
     * @return the largura
     */
    public long getLargura() {
        return largura;
    }

    /**
     * @param largura the largura to set
     */
    public void setLargura(long largura) {
        this.largura = largura;
    }

    /**
     * @return the nfe
     */
    public long getNfe() {
        return nfe;
    }

    /**
     * @param nfe the nfe to set
     */
    public void setNfe(long nfe) {
        this.nfe = nfe;
    }

    /**
     * @return the peso
     */
    public long getPeso() {
        return peso;
    }

    /**
     * @param peso the peso to set
     */
    public void setPeso(long peso) {
        this.peso = peso;
    }

    /**
     * @return the produto
     */
    public String getProduto() {
        return produto;
    }

    /**
     * @param produto the produto to set
     */
    public void setProduto(String produto) {
        this.produto = produto;
    }

    /**
     * @return the profundidade
     */
    public long getProfundidade() {
        return profundidade;
    }

    /**
     * @param profundidade the profundidade to set
     */
    public void setProfundidade(long profundidade) {
        this.profundidade = profundidade;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return the datahora
     */
    public String getDatahora() {
        return datahora;
    }

    /**
     * @param datahora the datahora to set
     */
    public void setDatahora(String datahora) {
        this.datahora = datahora;
    }

    /**
     * @return the filiais
     */
    public String getRemetente() {
        return remetente;
    }

    /**
     * @param remetente the remetente to set
     */
    public void setRemetente(String remetente) {
        this.remetente = remetente;
    }

    /**
     * @return the observacao
     */
    public String getObservacao() {
        return observacao;
    }

    /**
     * @param observacao the observacao to set
     */
    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }

    /**
     * @return the destinatario
     */
    public String getDestinatario() {
        return destinatario;
    }

    /**
     * @param destinatario the destinatario to set
     */
    public void setDestinatario(String destinatario) {
        this.destinatario = destinatario;
    }

    /**
     * @return the uforigem
     */
    public String getUforigem() {
        return uforigem;
    }

    /**
     * @param uforigem the uforigem to set
     */
    public void setUforigem(String uforigem) {
        this.uforigem = uforigem;
    }

    /**
     * @return the ufdestino
     */
    public String getUfdestino() {
        return ufdestino;
    }

    /**
     * @param ufdestino the ufdestino to set
     */
    public void setUfdestino(String ufdestino) {
        this.ufdestino = ufdestino;
    }

    /**
     * @return the filiais
     */
    public String getFiliais() {
        return filiais;
    }

    /**
     * @param filiais the filiais to set
     */
    public void setFiliais(String filiais) {
        this.filiais = filiais;
    }

    
    
}
