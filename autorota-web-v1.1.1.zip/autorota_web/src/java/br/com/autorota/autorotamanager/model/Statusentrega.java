/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.autorota.autorotamanager.model;

//import javax.persistence.Column;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import br.com.autorota.autorotamanager.model.Entrega;

/**
 *
 * @author ricardo.costa
 */
@Entity
public class Statusentrega extends Modelo<Statusentrega> implements Serializable{

     @Id
   // @Column(nullable=true, unique=true)
    private String status;
   /// @ManyToOne
    private String coleta;
    private String date;
    private String hora;
    
   // @OneToOne
 
    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }
    /**
     * @return the coleta
     */
    public String getColeta() {
        return coleta;
    }

    /**
     * @param coleta the coleta to set
     */
    public void setColeta(String coleta) {
        this.coleta = coleta;
    }

    /**
     * @return the data
     */
    public String getDate() {
        return date;
    }

    /**
     * @param date the data to set
     */
    public void setDate(String date) {
        this.date = date;
    }

    /**
     * @return the hora
     */
    public String getHora() {
        return hora;
    }

    /**
     * @param hora the hora to set
     */
    public void setHora(String hora) {
        this.hora = hora;
    }

    
}
