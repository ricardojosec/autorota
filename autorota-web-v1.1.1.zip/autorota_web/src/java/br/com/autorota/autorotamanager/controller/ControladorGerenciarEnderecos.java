/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.autorota.autorotamanager.controller;

import br.com.autorota.autorotamanager.model.Endereco;
import java.util.List;

/**
 *
 * @author ricardo.costa
 */
public class ControladorGerenciarEnderecos {
    
    private List<Endereco> listaEnderecos;
    
     private Endereco endereco;
   
   
    public ControladorGerenciarEnderecos() {
        endereco = new Endereco();
        
    }

    public List<Endereco> obterLista() {
        Endereco e = new Endereco();
        listaEnderecos = e.getList();
        System.out.println("Aqui");
        return e.getList();
    }
    
    
    
    
     public Endereco getEndereco() {
        return endereco;
    }

   
    public void setEndereco(Endereco endereco) {
        this.endereco= endereco;
    }
    
    
    public String add (){
       this.setEndereco(endereco);
       this.endereco.inserir( );
       return "cliente"; 
      
    }
    
    public String altera (){
       this.setEndereco(endereco);
       this.endereco.alterar( );
       return "novo_cliente"; 
      
    }
    
    public String del (){
       this.setEndereco(endereco);
       this.endereco.excluir( );
       return "novo_cliente"; 
      
    }

    
}



