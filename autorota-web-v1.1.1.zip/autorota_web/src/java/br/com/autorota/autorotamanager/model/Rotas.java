/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.autorota.autorotamanager.model;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


/**
 *
 * @author ricardo.costa
 */
@Entity
public class Rotas extends Modelo<Rotas> implements Serializable{
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long idRota;
    private String origem;
    private String destino;
    private String rastreio;
    private long datachegada;
    


    /**
     * @return the idRota
     */
    public long getIdRota() {
        return idRota;
    }

    /**
     * @param idRota the idRota to set
     */
    public void setIdRota(long idRota) {
        this.idRota = idRota;
    }

    /**
     * @return the origem
     */
    public String getOrigem() {
        return origem;
    }

    /**
     * @param origem the origem to set
     */
    public void setOrigem(String origem) {
        this.origem = origem;
    }

    /**
     * @return the destino
     */
    public String getDestino() {
        return destino;
    }

    /**
     * @param destino the destino to set
     */
    public void setDestino(String destino) {
        this.destino = destino;
    }

    /**
     * @return the rastreio
     */
    public String getRastreio() {
        return rastreio;
    }

    /**
     * @param rastreio the mdfe to set
     */
    public void setRastreio(String rastreio) {
        this.rastreio = rastreio;
    }

    /**
     * @return the datachegada
     */
    public long getDatachegada() {
        return datachegada;
    }

    /**
     * @param datachegada the datachegada to set
     */
    public void setDatachegada(long datachegada) {
        this.datachegada = datachegada;
    }
    

    
}
