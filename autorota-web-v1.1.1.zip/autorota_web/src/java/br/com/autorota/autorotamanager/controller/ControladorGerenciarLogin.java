/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.autorota.autorotamanager.controller;

import br.com.autorota.autorotamanager.dao.UsuarioDAO;
import br.com.autorota.autorotamanager.model.Usuario;
import java.io.Serializable;
import javax.annotation.ManagedBean;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Named;
/**
 *
 * @author ricardo.costa
 */

@ManagedBean
@RequestScoped
@Named(value = "ControladorGerenciarLogin")
public class ControladorGerenciarLogin implements Serializable {
    
    private Usuario usuario;

    
    public ControladorGerenciarLogin(){
        usuario = new Usuario();
    }
    public Usuario getUsuario() {
        return usuario;
    }

    /**
     * @param usuario the usuario to set
     */
    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
    
public String verificarDados() throws Exception {
	UsuarioDAO usDAO = new UsuarioDAO();
	Usuario  us;
	String resultado;

	try {
		us = usDAO.verificarDados(this.usuario);
		if (us != null) {
			FacesContext.getCurrentInstance().getExternalContext()
				.getSessionMap().put("usuario", us);

			resultado= "index?faces-redirect=true";
                        
			} 
                else {
                        resultado = "login";
			}
		}
        
        catch (Exception e) 
       
        { throw e;
		}  

	return resultado; 
}



public boolean verificarsessao() {
	boolean estado;
	
	if (FacesContext.getCurrentInstance().getExternalContext()
                .getSessionMap().get("usuario") == null) {
		estado = false;
	}else {
		estado = true;
	}
        
	return estado;
}

public String encerrarsessao () {
	FacesContext.getCurrentInstance().getExternalContext()
		.invalidateSession();
	return "login?faces-redirect=true";
}


}


    
    
    

