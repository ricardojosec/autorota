/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.autorota.autorotamanager.dao;

import br.com.autorota.autorotamanager.model.Usuario;
import br.com.autorota.autorotamanager.util.HibernateUtil;
import org.hibernate.Query;
import org.hibernate.Session;

/**
 *
 * @author ricardo.costa
 */
public class UsuarioDAO {
    
	private Session session;

	public Usuario verificarDados(Usuario usuario) throws Exception {
	Usuario us = null;

	try {
		session = HibernateUtil.getSessionFactory().openSession();
		String hql = "FROM Usuario WHERE email = '" +usuario.getEmail() + "'and senha ='" + usuario.getSenha() + "'";


		Query query = session.createQuery(hql);
		
		if (!query.list().isEmpty()) {
			us = (Usuario) query.list().get(0);
		}

	}catch (Exception e) {
		throw e;
		}
		return us;
                
	}
        
        
        
}
    

