
package br.com.autorota.autorotamanager.model;


import java.util.ArrayList;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;



@Entity
public class Cliente extends Modelo<Cliente> {
       
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long idcliente; 
    
    @Column(nullable=true, unique=true)
    private String cpf;

    @Column(nullable=true, unique=true)
    private String cnpj;
    
    @Column(nullable=true)
    private String nome;
    
    @ManyToMany(mappedBy = "entrega")
    private List<Endereco>enderecos;
    
    @OneToOne
    private Entrega entrega;
    
    //construtor da classe
    public Cliente(){
        idcliente=00;
        nome="";
        cpf="";
        cnpj="";
        enderecos= new ArrayList<Endereco>();
        
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the cpf
     */
    public String getCpf() {
        return cpf;
    }

    /**
     * @param cpf the cpf to set
     */
    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    /**
     * @return the cnpj
     */
    public String getCnpj() {
        return cnpj;
    }

    /**
     * @param cnpj the cnpj to set
     */
    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    /**
     * @return the enderecos
     */
    public List<Endereco> getEnderecos() {
        return enderecos;
    }

    /**
     * @param enderecos the enderecos to set
     */
    public void setEnderecos(List<Endereco> enderecos) {
        this.enderecos = enderecos;
    }

    /**
     * @return the idcliente
     */
    public long getIdcliente() {
        return idcliente;
    }

    /**
     * @param idcliente the idcliente to set
     */
    public void setIdcliente(long idcliente) {
        this.idcliente = idcliente;
    }

    /**
     * @return the entrega
     */
    public Entrega getEntrega() {
        return entrega;
    }

    /**
     * @param entrega the entrega to set
     */
    public void setEntrega(Entrega entrega) {
        this.entrega = entrega;
    }

}