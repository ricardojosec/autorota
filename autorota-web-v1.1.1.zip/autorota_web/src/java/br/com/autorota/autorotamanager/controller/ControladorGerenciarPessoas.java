/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.autorota.autorotamanager.controller;

import br.com.autorota.autorotamanager.dao.GenericDAO;
import br.com.autorota.autorotamanager.model.Fisica;
import br.com.autorota.autorotamanager.model.Juridica;
import br.com.autorota.autorotamanager.model.Pessoa;
import br.com.autorota.autorotamanager.model.Usuario;
import java.io.Serializable;
import java.util.List;
import javax.annotation.ManagedBean;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

/**
 *
 * @author ricardo.costa
 */
@ManagedBean
@SessionScoped
@Named(value = "ControladorGerenciarPessoas")

public class ControladorGerenciarPessoas implements Serializable {
    
 private List<Fisica> listaFisicas;
 private List<Juridica> listaJuridicas;
 private List<Usuario> listaUsuarios;
 private List<Pessoa> listaPessoas;
 
 
    /**
     * Creates a new instance of ControladorGerenciarCliente
     */
    
    private Fisica fisica;
    private Juridica juridica;
    private Usuario usuario;
    
   
   
    public ControladorGerenciarPessoas() {
        fisica = new Fisica();
        juridica = new Juridica();
        usuario = new Usuario();
    }

    public List<Pessoa> obterLista() {
        Fisica f = new Fisica();
        listaPessoas = f.getList();
        System.out.println("Aqui");
        return f.getList();
    }
    /**
     * @return the Fisica
     */
    public List<Pessoa> obterListaJuridica() {
        Juridica j = new Juridica();
        listaPessoas = j.getList();
        System.out.println("Aqui");
        return j.getList();
    }
    
    public List<Pessoa> obterListaUsuario() {
        Usuario u = new Usuario();
        listaPessoas = u.getList();
        System.out.println("Aqui");
        return u.getList();
    }
    
    /** BEAN Para pessoa fisica */
    
    public Fisica getFisica() {
        return fisica;
    }

   
    public void setFisica(Fisica fisica) {
        this.fisica= fisica;
    }
    
    /**
     * @return the listaFisica
     */
    public List<Fisica> getListaFisica() {
        return listaFisicas;
    }
    
    /**public Pessoa search(long id){
        Pessoa p = new Pessoa();
        System.out.println("Aqui");
        return p.search(id);
              
    } */

    /**
     * @param listaFisica the listaFisicas to set
     */
    public void setListaFisica(List<Fisica> listaFisica) {
        this.listaFisicas = listaFisicas;
    }
    

    
    public String add (){
       this.setFisica(fisica);
       this.fisica.inserir( );
       this.fisica = new Fisica ();
       return "cliente_pessoa_fisica"; 
      
    }
    
    public String alterar(Fisica f){
     this.fisica = f;
    
     return "alterar_pessoa_fisica";
      
    }
    
    public String alterar() {
	this.fisica.alterar();
       this.fisica = new Fisica ();
	return "alterar_pessoa_fisica";
    }    
    
    public void del(Fisica f){
        this.fisica.excluir( );
      
    }
    
    
    /** BEAN Para pessoa juridica */
    
    
    public Juridica getJuridica() {
        return juridica;
    }

   
    public void setJuridica(Juridica juridica) {
        this.juridica= juridica;
    }
    
    /**
     * @return the listaFisica
     */
    public List<Juridica> getListaJuridica() {
        return listaJuridicas;
    }
    
    /**public Pessoa search(long id){
        Pessoa p = new Pessoa();
        System.out.println("Aqui");
        return p.search(id);
              
    } */

    /**
     * @param listaJuridica the listaFisicas to set
     */
    public void setListaJuridica(List<Juridica> listaJuridica) {
        this.listaJuridicas = listaJuridicas;
    }
    

    
    public String addJuridica (){
       this.setJuridica(juridica);
       this.juridica.inserir( );
       this.juridica = new Juridica ();
       return "cliente"; 
      
    }
    
    public String alterarJuridica(Juridica j){
     this.juridica = j;
     
     return "alterar_pessoa_juridica";
      
    }
    
    public String alterarJuridica() {
	this.juridica.alterar();
        this.juridica = new Juridica ();
	return "alterar_pessoa_juridica";
    }    
    
    public void delJuridica(Juridica j){
        this.juridica.excluir( );
      
    }
    
    
    /** BEAN Para pessoa Usuario
     * @return  */
    
    public Usuario getUsuario() {
        return usuario;
    }

   
    public void setUsuario(Usuario usuario) {
        this.usuario= usuario;
    }
    
    /**
     * @return the listaFisica
     */
    public List<Usuario> getListaUsuario() {
        return listaUsuarios;
    }
    
    /**public Pessoa search(long id){
        Pessoa p = new Pessoa();
        System.out.println("Aqui");
        return p.search(id);
              
    } */

    /**
     * @param listaUsuario the listaFisicas to set
     */
    public void setListaUsuario(List<Usuario> listaUsuario) {
        this.listaUsuarios = listaUsuarios;
    }
    

    
    public String addUsuario (){
       this.setUsuario(usuario);
       this.usuario.inserir( );
       this.usuario = new Usuario();
       return "ajustes"; 
      
    }
    
    public String alterarUsuario(Usuario u){
     this.usuario = u;
    
     return "alterar_usuario";
      
    }
    
    public String alterarUsuario() {
	this.usuario.alterar();
       this.usuario = new Usuario ();
	return "alterar_usuario";
    }    
    
    public void del(Usuario u){
        this.usuario.excluir( );
      
    }
    public void login(Usuario u){
        this.usuario = u;
        this.usuario.getUsuarioLoginSenha(u.getEmail(), u.getSenha());
      
    }
    
    
   
}



